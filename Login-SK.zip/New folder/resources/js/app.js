import { authJS } from './auth'

authJS()